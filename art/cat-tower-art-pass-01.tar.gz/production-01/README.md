# Cat Tower production pass 01 — appearance review required

The user selected Cats A + Sunroom A in review card `106a82ae-ebb8-471b-8068-b89cc25b475e` (`sunroom`). This approves the visual direction, not these subsequent native exports. Do not integrate them as approved art until the user reviews this pass.

Actual Gemini-generated concept sources and receipts: `../review-01/`. These SVGs are newly authored editable adaptations of that selected visual direction, not direct Gemini-generated transparent PNGs. There was no provider change and no further paid generation. Existing generation cost remains $0.1163499. No audio was generated.

## Files and layout

- Four 512x384 body SVGs: default cream, ginger, tuxedo and calico. No baked expression, contact shadow or oval base; tail stays within body canvas.
- Six 128x128 shared expression SVGs: idle, focused, happy, surprised, worried, dizzy.
- Sunroom-derived warm quiet backdrop: 576x1024 SVG, no floor/UI/cats painted in. Scenery was simplified substantially to meet Architect's quiet-95%-width requirement.
- Separate floor, guide shadow, star and puff; six currentColor UI icons. Icons require accessible HTML labels. Warning is never color-only.
- `manifest.json`: real file sizes, declared source geometry and approval provenance. Body logical W/H=1.55, bottom-center pivot, face bodyUV(0.50,0.48), face drawn width=0.45W.

All 21 runtime SVGs together are 8,849 bytes before HTTP compression. Source scripts and reviews are not runtime imports. `export.pl` recreates SVGs; it makes no network requests and contains no credentials. The earlier `generate.pl` reads the secure key file only when explicitly run to generate a named image; never ship it to the browser.

## Integration and remaining checks

These are native SVG deliverables rather than PNG exports. Architect's contract permits approved native SVG bodies and prefers vector backgrounds; obtain user approval for this rendered pass. Face overlays are SVG rather than the requested PNG and need Developer/Architect agreement, or offline raster export at exactly 128x128. SVG faces avoid loss at mobile scale but do not assume acceptance.

Use each SVG as a standalone image so its local clipPath IDs do not collide; prefix IDs if embedding several directly in one DOM. Coordinates are declared art metadata, never inferred from alpha. Confirm alignment and decorative overflow in the developer's renderer, actual 80px body width, dark-coat contrast, browser SVG decoding and landscape crop. No browser gameplay test or raster export was performed by Studio. No accessibility-conformance claim is made.

Audio remains the documented trigger plan; xAI/Grok provider is confirmed but no voice selection, audio generation or additional charge is implied.
