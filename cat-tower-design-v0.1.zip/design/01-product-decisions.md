# Product, scope and decisions

## Supplied direction

The user wants cute cats stacked into a tower. The user explicitly confirmed a responsive browser app first for desktop and mobile browsers; native Android/other packaging is a later phase. OG's authorized brief adds quick tap-to-drop rounds, wobbles, expressive cats, funny collapses, records and unlocks. Architect owns detailed gameplay and technical decisions; Developer implements; Studio prepares art/audio; Playtester independently checks behavior. Work runs on OpenBot's VPS. Gemini is intended for images. OG reports that the user selected xAI/Grok and Studio verified its saved key; Architect has not independently verified any provider key or connection. No audio has been generated according to that report.

These are directions, not evidence that integrations or infrastructure work.

## Confirmed user decisions — updated 2026-11-16

- **Browser first:** OG message `884523e8-d29b-453d-b274-5d87841fc2f0` relays the user's explicit words: “browser app first and then Android or anything ... First ... browser app.” The initial deliverable is the responsive browser application, including desktop and mobile browsers. Native Android/other packaging is later work. This platform order is confirmed, not an Architect assumption.
- **Provider selection:** OG message `7498214b-61e7-4032-9d12-7ca5e8294af4` confirms the user's xAI/Grok selection and relays Studio's key-verification report. Selection does not approve any particular audio content or new charges. Architect did not inspect the key and does not independently certify integration readiness.
- **Selected visual direction:** OG message `4b698ce0-9d98-4a0e-9ae7-101059f93d39` relays the user's review of three previews and selection of **Cats + Sunroom A**. This supersedes the earlier request for more options. Use the Cats A rounded loaf silhouettes, cocoa outlines and cream/peach/sage palette with Sunroom A. Remove oval bases/contact shadows from bodies, tuck upright tails and separate the platform. Studio may prepare production assets within its existing authorization; materially new visual choices return for user review. Selection approves the direction, not uninspected runtime exports, additional charges or public release. See [production brief](08-selected-art-production.md).

No user input is currently required to continue local development and production preparation in the selected direction. Production-export review and public launch authorization are later gates, not present implementation blockers.

## Product goal

Within a few seconds of opening the game, a player can understand “drop this cat onto the tower.” A successful landing should feel soft and satisfying; a risky landing should visibly explain its danger; a collapse should be funny and invite another round. Skill is timing and keeping the tower balanced, with no hidden random failure. Initial expected session: several 20–90-second rounds; this is a design target to validate, not a promise or measured result.

## MVP scope

Required screens: Home, How to play, live game, Pause/Settings overlay, Results, Cat collection. A single static application includes Classic and Assist modes, a short dismissible tutorial, scoring, independent mode records, local progress, one default cat and three unlockable cosmetic bodies. One quiet background/environment is enough. Shapes and procedural sound are acceptable prototype assets.

Classic: one moving cat, tap/Space/Enter to drop, tower grows, instability ends the round. Assist: stationary cat adjusted with left/right controls, same drop and balance rules, no time pressure. It is explicitly an easier separate mode; no implication of identical skill difficulty.

Out of MVP: multiplayer, accounts, server leaderboards, competitive fairness enforcement, cloud sync, purchases, currency, daily quests, energy, ads, revives, power-ups, varied cat masses/sizes, live weather, variable-width slicing, level map, native packaging, app-store delivery, PWA/offline installation, voice generation and runtime AI. These are future options, not committed requirements.

## Architect defaults — approved for prototype implementation, not user preference claims

| ID | Default | Reason / consequence |
|---|---|---|
| D01 | Endless rounds; failure on one unsupported/unstable landing | Clear loop and useful local record; no lives or revival UI |
| D02 | Controlled stacking model with world-space support and center-of-mass checks | Reproducible and tunable; not a rigid-body simulator |
| D03 | Identical logical cat width, height and mass | Cosmetically fair; avoids surprising art-driven collisions |
| D04 | Perfect drops get a small explicit snap and score bonus | Forgiving timing and readable skill reward |
| D05 | All previous contacts participate in stability checks | A top placement can tip a visibly leaning whole tower |
| D06 | Local-only profile, no active-round restore after refresh | Small scope; record/progress checkpoints survive committed placements |
| D07 | Automatic pause when tab hides; explicit resume | Returning to a phone/browser cannot silently lose a round |
| D08 | Sound unlocked only by interaction; settings persist | Browser-safe and controllable; audio is not needed to play |
| D09 | Assist controls and reduced-motion settings | Access for users who need more time or less animation |
| D10 | No automatic restart, no forced sound, no failure punishment | User chooses replay; progress is never spent |
| D11 | TypeScript, Vite, Canvas 2D and semantic DOM | Small dependency surface and reusable simulation |
| D12 | Cosmetic bodies: default, ginger, tuxedo, calico IDs | Working IDs; map four selected Cats A coats without changing physics or adding unlocks; public names/branding remain working labels |

## User decisions still pending

These do not block placeholder development:

- Material departures from the selected Cats + Sunroom A direction, final branding and names. The base direction is approved; production exports still need geometry/alpha/viewport review before integration. Routine cleanup within that direction needs no repeat selection question.
- Final soundtrack/voice content and any new paid API use. xAI/Grok provider selection is resolved; audio content and additional charges are separate approvals. Default implementation has optional short procedural effects and no voice.
- Public host/domain, public release, monetization or any paid infrastructure. Do not deploy from this brief.
- Later mobile app and any expanded mode. Browser build should avoid platform coupling but does not include native packaging.

If the user later wants fully emergent rigid-body balancing or a different core loop, Architect revises these specs before Developer substitutes a physics engine. Prototype implementation can proceed with D01–D12.

## Platform and quality targets

- Design viewport: portrait 390×844 CSS pixels. Supported layout range: 320 CSS px wide through desktop; short landscape gets a compact layout, never a forced rotation screen.
- Initial browser matrix to validate: current and previous major Chrome/Edge/Firefox desktop; current and previous major iOS Safari; current Android Chrome. This is a target matrix, not verified compatibility.
- Touch, mouse and keyboard provide all gameplay/menu actions. Visible focus, screen-reader labels and textual state feedback are required. Timing game parity for blind players is not claimed; Assist offers deliberate placement and readable alignment/stability feedback.
- Target smooth 60 fps on a representative mid-range phone; 30 fps remains usable without simulation speed changes. Verify on named devices before claiming compliance.
- Prototype startup code budget: <=200 KB gzip JS+CSS excluding assets; release first-load transfer <=2 MB; default cat/background ready without optional skins or audio. These are gates to measure.
- No external fonts, required third-party requests or personally identifiable data. No analytics unless separately approved.

## Risks and responses

| Risk | Response / evidence needed |
|---|---|
| Tower stability feels surprising | Visible danger gauge, endangered joint cue; Playtester near-edge scenarios |
| Controlled wobble looks too artificial | Art/transform polish after core rules pass; never disguise gameplay changes as art |
| Classic too fast for touch users | Gentle speed ramp and Assist; measure early-round success rate |
| Approved art does not fit body rectangle | Explicit content/collider bounds and fixed transform contract; Studio feedback before integration |
| Storage blocked or corrupted | Safe defaults, session-only fallback, visible notice, no crash |
| Runtime/dependency mismatch on VPS | Developer inspects installed versions and locks compatible tooling; no infrastructure claims now |
| Audio/device behavior varies | Play silently on failure; manual autoplay/visibility checks |
| User has another intended game direction | Mark defaults clearly; show a placeholder local prototype for review before polishing |
