# Implementation milestones and delegation

The Architect owns the design, with implementation, art and playtesting owned by their respective roles.

## Milestones and dependencies

| Milestone | Deliverable / scope | Dependencies | Gate |
|---|---|---|---|
| M0 Specification baseline | This document set and arithmetic review | Authorized user brief | Cross-document review and fixtures consistent |
| M1 Pure engine | Types/config, seeded motion, states, placement/COM, scoring, generation guards, deterministic checks | M0 | AC01,03–07 domain portions, core AC08/09 cases |
| M2 Playable local placeholder | Loopback app with Canvas/DOM, controls, Home/game/pause/results, both modes, clear reactions | M1 | AC02,08,09,14 available-browser portions; no external required resources |
| M3 Durable MVP shell | Profile service/lock/degraded mode, records/unlocks/collection/settings/tutorial | M1+M2 | AC10–13,15; exact save cases and settings |
| M4 Art/polish integration | Reviewed exports in approved Cats + Sunroom A direction, audio/camera/expressions/accessibility/performance refinements | M2+M3; production-export technical review | AC14–19; provenance and actual measurements |
| M5 Independent candidate review | Playtester findings, Architect conformance review, fixes and limitations | M3; M4 for art-complete release | No unresolved critical gameplay/save/input failures; user visual approval |
| M6 Public release | Approved host/domain and release procedure | M5 + explicit user release authorization | Separate approval; not delegated now |

Milestones are dependency gates, not time promises. M1 is the first delegated implementation task. Developer must stop at that task's boundary and report before Architect assigns M2; do not infer authority for the entire roadmap from receipt of these specs. Architect reviews returned tests/code against the stated rules.

Delegation record: CT-DEV-001 sent to Developer in message `6c3b3106-a2e4-46b7-b7a2-f7ac306d5bf8` with `expectsReply:true`; delivery queued. No implementation result has been received or reviewed in this design handoff. Studio received the full asset contract location in informational message `1cb329bf-8688-4c07-b02e-adb569299c83`, following the earlier requirements request. Update 2026-11-16: Studio supplied concept sources; OG relayed user selection of Cats + Sunroom A. Production requirements are in08; runtime exports have not yet been reviewed. This update does not expand Developer's M1 assignment.

## Task CT-DEV-001 — pure simulation foundation

Goal: implement M1 in `app` with the smallest local toolchain necessary to run deterministic tests. Read README and documents01–06 first. Inspect runtime, repository/instruction state and available dependencies. Create a clean app package if absent; do not overwrite user files. No public repository push, deployment, paid API, Studio final-art lock, system-runtime install or additional agent delegation. If no compatible JavaScript runtime is available, a project-local portable Node/toolchain from its official distribution is within this local development task: verify the downloaded artifact checksum against official release metadata, pin/report versions, keep it out of source/build artifacts and do not alter system configuration. Report any actual network/security rejection rather than bypassing it.

In scope:

1. `src/domain/{types,balance,rng,placement,score,engine}.ts` and minimal strict TypeScript/build/test configuration. The engine includes Classic+Assist, cues/falling/settling/collapse/pause/results, synchronous lifecycle controls, immutable snapshots, generation guards and typed events. Browser rendering is outside this task.
2. Complete config exactly as gameplay doc; pure placement function must check every support via reverse suffix load accumulation. Include default floor, pre-snap grading and correct failure classification. No physics framework substitute or silently simplified balance.
3. Meaningful domain tests using fixtures1–13 and key state scenarios in06: duplicate/old inputs, pause/resume counters, no repeated score on results/replay, seed repeatability, mode period behavior and top-only misses. Use a compatible available runner and lock reproducible dependency versions; report command evidence.
4. Brief implementation README with file map, actual versions/commands, test output summary, design ambiguities and anything not implemented. No rendered playable build claim at M1.

M1 review acceptance: pure modules compile/typecheck, tests pass, no DOM/storage/audio imports in domain, fixtures including old-floor COM failure pass, emitted placement event is exactly once, no live RNG consumption by presentation, public methods cannot silently mutate prior published snapshots. Make repeated1000-cat fixture computationally linear per evaluation; a timing report on VPS is useful but is not phone validation.

Return to Architect: absolute paths; concise behavior/result; actual commands/exits/counts; any deviations/questions; no claims based on unrun tests. If a spec ambiguity affects behavior, ask Architect before changing that behavior; implement independent unambiguous parts meanwhile. Do not start M2 until Architect sends its bounded assignment after review.

## Planned follow-on assignments (not yet assigned)

CT-DEV-002: M2 browser vertical slice, placeholder renderer/DOM/input/loop/lifecycle, local-only preview and available-browser checks. CT-DEV-003: M3 profile/settings/tutorial/collection and fault checks. CT-DEV-004: M4 polish and approved art integration. Architect may combine or split later tasks based on reviewed foundation; scope changes will be explicit.

Studio early task (historical): coordinate already authorized art-option work, deliver geometry/manifest/provenance requirements and user-facing options; that message did not authorize paid calls or make a final selection. Architect message `f9dc56cb-1523-46f4-a6ee-5491c83bb612` supplied initial bounds. Current task CT-ART-002: prepare Cats + Sunroom A production exports under08 and05; sent in message `286cc073-e016-4406-b8d7-490469b0923e` with `expectsReply:true`, queued. Production response/review remains pending. Keep art optional while Developer builds. No new paid/audio/public-release authority is added.

Playtester assignment occurs after M2/M3 has a real runnable app. Provide this acceptance document plus exact loopback access/start command and build identifier. Do not ask Playtester to validate a game that does not exist. Physical-device or service access gaps must be reported, not inferred as passing.

## Reporting and approvals

Architect sends OG document paths, design defaults, remaining user choices and Developer/Studio status. Development delegation uses `openbot.send_message` with `expectsReply:true`; results are reviewed before follow-on scope. OG/user decide final art, any consequential product direction change, new charges and public release. No blocker exists for local placeholder M1 from unfinished art/audio/hosting. Responsive desktop/mobile browser delivery first is a confirmed user decision; native packaging remains a later phase. xAI/Grok provider selection is resolved, while audio content approval and new charges remain separate. See01 for the dated user-decision record.
