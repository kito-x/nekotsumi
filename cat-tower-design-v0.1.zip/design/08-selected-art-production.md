# Cats + Sunroom A — production handoff

Date: 2026-11-16 UTC. Owner: Architect; production owner: Studio.

## Decision and scope

OG message `4b698ce0-9d98-4a0e-9ae7-101059f93d39` reports that the user reviewed three attached previews and selected **Cats + Sunroom A**. That direction is approved. Reference sources: [Cats A](../art/review-01/cats-A.png) and [Sunroom A](../art/review-01/background-A-sunroom.png). Studio owns original prompts/receipts and provenance in that directory. Architect inspected both sources; they are concept boards, not runtime-ready sprites.

Preserve broad rounded loaf cats, cocoa outlines, tucked paws, soft cream/peach/sage colors, and the warm sunroom. Remove each oval base and baked contact shadow; tuck upright tails within the silhouette envelope. Extract body and face layers independently. Remove any original face from the body before supplying overlays. Separate the painted floor/platform from the backdrop. Soften architectural lines behind moving/stacked cats. These are production corrections within the selected direction, not a new art vote. Material changes to style, palette, silhouettes or environment return to user review through OG.

The existing four cosmetic IDs and unlock thresholds stay unchanged: `default` uses cream, `ginger` orange, `tuxedo` the charcoal reference, `calico` patchwork. These are internal IDs; do not add tuxedo markings merely to match the ID. Names remain working labels. Plum/Mint may remain concept references; no additional playable coats or progression are required for MVP. No art approval changes collider dimensions, mass, support rules or scoring.

## Dimensions and anchors

Target reference layout is 390×844 CSS px, responsive down to 320 CSS px and into short landscape. Do not bake this screen resolution into sprites or physics. Cats share world collider width 2.6 and height 2.6/1.55, with a bottom-center pivot.

| Deliverable | Export and geometry | Constraints |
|---|---|---|
| Four body sprites | Transparent RGBA PNG, 512×384 each; common logical rectangle `[48, 80, 416, 416/1.55]` in source pixels | Use this same rectangle on every coat; do not auto-trim or infer collision from alpha |
| Body pivot | Source point `[256, 80 + 416/1.55]`, approximately `[256, 348.3871]` | Bottom-center of the logical rectangle, not PNG bounds; source y increases downward |
| Decorative overflow | Up to 41.6 px beyond each logical side; 67.0968 px above logical top; 13.4194 px below logical bottom | Transparent canvas contains all art; tucked tails, ears/paws never imply another support platform |
| Six expression overlays | Transparent RGBA PNG 128×128 each: `idle`, `focused`, `happy`, `surprised`, `worried`, `dizzy` | Shared overlay anchor; neutral coat color; no changing body silhouette. Map anticipation→focused, proud→happy, startled→surprised |
| Face placement | Overlay center at logical-body UV `[0.50, 0.48]`; preserve this point across expressions | Renderer scales full overlay canvas to at most 0.50 logical body width; verify readability at an 80 px wide body. No automatic trim |
| Sunroom backdrop | Portrait runtime PNG/WebP 576×1008, matching original 768×1344 proportions; larger source retained separately | No baked text/UI/platform/contact shadows; keep roughly 95% of play-panel width visually quiet at travel extremes. Gentle light/low-contrast architecture may remain |
| Separate floor/platform | Canvas/CSS path preferred; if illustrated, transparent 512×128 with declared top-line y and center | Physical floor is centered, width 4.4 world units; renderer maps declared top to floor y=0. No extra apparent shelves |
| Optional shadow/effects | Canvas/vector preferred; optional transparent 128×64 shadow and 64×64 puff/star | No baked shadows on body; effects are decorative, never collision/support cues; no atlas required for first handoff |

The logical rectangle and pivot above turn the earlier illustrative05 example into the selected production target. Studio must report actual metadata, not copy numbers for differently placed artwork. If exact export placement cannot be achieved, return the proposed bounds for Architect review before delivery; retain the 1.55:1 collider and common anchor.

Backdrops remain stationary in screen space while the tower camera rises; the physical floor stays in world space and can leave view. Peripheral props must remain behind cats, including at travel extremes. Prefer containing/letterboxing the portrait play panel and extending flat room color into desktop margins over stretching the artwork. Validate portrait and short-landscape crop; no gameplay controls disappear. DOM title, score, pause, stability labels, Drop and Assist controls remain separate. No title mark, brand name, extra UI screen or animation rig is required for this production batch.

## Reactions and motion

Use the action/reaction priorities and timing in05. Bodies stay face-free and geometrically constant. Renderer owns bottom-center squash/stretch, wobble and collapse transforms; no alternate pose may silently change collision. Shared expressions must support focused aim, surprised fall, happy landing, worried low stability, and dizzy collapse. Reduced motion uses static faces/highlights with no spin, shake, sway or particles. Avoid distressed/injured depictions and flashing effects.

## First handoff and review

Deliver cream body + all six faces + cleaned sunroom first, then the three optional coat exports. Put production files under `art/production-01/` (create if absent), with contact sheets and source files separate from runtime exports. Do not overwrite review-01 sources or receipts.

Include a manifest draft using05's shape, real local relative URLs, source dimensions, logical bounds, pivot, face-anchor convention, encoded file bytes, provenance/rights notes, and this approval reference. Mark exports as awaiting technical review; concept-direction approval must not be represented as a completed runtime-quality check. No claim that exports exist until they are delivered.

Architect checks transparent edges/no opaque matte, body/face alignment, full decorative envelope, no oval bases/upright tail protrusions, correct aspect/pivot and mapping, and legibility on an 80 px body. Developer later checks manifest loading/fallbacks, actual viewport/crop, contrast and consistent gameplay across coats. Local synthetic contact sheets can establish sprite alignment, not device or game validation. Require separate screenshot evidence of game integration when available.

Transfer budgets: default body + faces ≤250 KB; all optional coats together ≤600 KB; backdrop ≤350 KB; optional audio ≤400 KB. Total release first-load budget stays ≤2 MB. Report actual encoded bytes and any budget variance; do not discard alpha to meet a size target. Lossless WebP alternatives may be proposed with PNG source retained. No runtime AI/network generation or remote asset dependency.

## Audio and authorization

xAI/Grok is the confirmed provider choice per OG; its saved key/integration has not been independently checked by Architect. OG says use it as appropriate **within authorized scope**. This handoff commissions visual production only and adds no paid-call allowance or audio-content approval. Keep procedural prototype cues from05; no new voice/music generation is needed. Studio should report any audio-specific proposal or charge requiring approval before acting. Public deployment remains outside this task.
