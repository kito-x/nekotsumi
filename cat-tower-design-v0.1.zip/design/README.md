# Cat Tower — implementation design v0.1

Status: implementation-ready prototype specification; balance values are initial tuning values, not playtest findings. Created 2026-11-15 UTC. Owner: Cat Tower Architect.

## Start here

1. [Product, scope and decisions](01-product-decisions.md)
2. [Gameplay, balance and state rules](02-gameplay-rules.md)
3. [High-level architecture](03-hld.md)
4. [Low-level design, contracts and persistence](04-lld.md)
5. [UX, action/reaction matrix and asset requirements](05-ux-assets.md)
6. [Acceptance criteria and test scenarios](06-acceptance.md)
7. [Implementation milestones and delegated work](07-implementation.md)
8. [Selected art direction and production handoff](08-selected-art-production.md)

These files specify a browser game, not an already implemented or validated game. Source code belongs in `app`. Studio owns its separate art-option files. No existing application, API connection, hosting configuration, device compatibility or game balance was verified during this design task.

Decision update 2026-11-16: user explicitly confirmed responsive desktop/mobile browser delivery first, with native Android/other packaging later, and selected **Cats + Sunroom A** through OG. The visual direction is approved; production exports still require technical review. xAI/Grok provider selection is resolved per OG; key verification is Studio-reported and not independently checked here. Audio content/new charges and public release remain separate gates. No user input currently blocks local development. See01 for source messages and08 for the production contract.

## Authority and constraints

OG message `1f2ff18f-8185-4e5c-9c41-443589e097da` relays user authorization: “ask the Cat Tower architect to design the HLD LLD in details ... rules and everything ... start its work ... let's go start the work.” OG requests detailed specifications, early Studio coordination and bounded Developer implementation after specifications. This activates the next-task condition in the setup instructions.

Authorized: local design and implementation with placeholders, Studio coordination, local builds and checks, and preparation of production assets in the user-selected Cats + Sunroom A direction within Studio's existing authorization. This specification grants no new paid-service, public-deployment or external-posting authority. Materially new visual choices require user review. Architect decides routine design/engineering details; Developer raises ambiguities rather than changing rules independently.

## Reading and change control

- `01` separates supplied user direction, Architect defaults and decisions still requiring user approval.
- `02` is authoritative for gameplay math. `04` translates that math to code contracts. If they conflict, stop that affected implementation and ask Architect; do not silently choose a variant.
- Numbers are centralized under `BalanceConfig` in implementation. A tuning change increments `balanceVersion`; save schema and balance versions are independent.
- All MVP criteria in `06` are required for a release candidate. Individual milestones have smaller gates in `07`.
- Present builds as prototypes until Playtester validates and the user approves the visual direction and public release.

## Main decisions

- Endless one-cat-at-a-time rounds, one failed placement ends a round, immediate replay.
- Fixed-size cats and deterministic support/center-of-mass checks; wobble and collapse are presentation, not hidden randomness.
- Classic timing mode and separate Assist mode with stationary positioning controls and separate records.
- Canvas 2D playfield, semantic HTML menus/controls, TypeScript and Vite; no runtime game framework or physics dependency required.
- Local browser profile with best records, cumulative placements, three cosmetic unlocks and settings. No login or backend in MVP.
- Art and audio have safe placeholders. No runtime AI calls, generated voices, telemetry, ads, payments, cloud saves or leaderboards.

## Design review status

Cross-document review and model-level verification are recorded in `design-review.md`. Build tests, real-device checks and playtest evidence must come from Developer/Playtester and must not be inferred from this document set.
